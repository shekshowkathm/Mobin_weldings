import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { HomeRoutingModule } from './home-routing.module';

import { RegisterService } from './service/register.service';

import { MessageModule } from 'primeng/message';
import { ToastModule } from 'primeng/toast';
import { ConfirmationService, MessageService } from 'primeng/api';
import { ConfirmPopupModule } from 'primeng/confirmpopup';



@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    HomeRoutingModule,
    MessageModule,
    ToastModule, ConfirmPopupModule
  ],
  providers:[
    RegisterService,MessageService,ConfirmationService
  ]
})
export class HomeModule { }
