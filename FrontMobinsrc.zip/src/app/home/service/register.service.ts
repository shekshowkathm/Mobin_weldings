import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '../../../environments/environment.development';
import { Observable, catchError } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class RegisterService {
  public registerAPI = environment.localdomain + 'api/userregister';
  public loginAPI = environment.localdomain + 'api/commonlogin';
  public contactRequestAPI = environment.localdomain + 'api/contactregister';

  private handleError(error: any): Promise<any> {
    console.error('An error occurred', error); // for demo purposes only
    return Promise.reject(error.message || error);
  }

  constructor(private http: HttpClient) {}

  private getRequestOptionsWithAdmin(): { headers: HttpHeaders } {
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      Authorization: 'Bearer ' + environment.adminToken,
    });
    return { headers };
  }

  registerPostData(data: any): Observable<any> {
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
    });

    return this.http
      .post<any>(this.registerAPI, data, { headers })
      .pipe(catchError(this.handleError));
  }

  loginPostData(data: any): Observable<any> {
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
    });

    return this.http
      .post<any>(this.loginAPI, data, { headers })
      .pipe(catchError(this.handleError));
  }
  contactPostData(data: any): Observable<any> {
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
    });

    return this.http
      .post<any>(this.contactRequestAPI, data, { headers })
      .pipe(catchError(this.handleError));
  }
}
