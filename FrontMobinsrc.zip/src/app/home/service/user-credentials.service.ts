import { Injectable } from '@angular/core';
import { Vendor } from '../model/vendor';
import { Admin } from '../model/admin';
import { User } from '../model/user';
import * as CryptoJS from 'crypto-js';
import { environment } from '../../../environments/environment.development';

@Injectable({
  providedIn: 'root',
})
export class UserCredentialsService {
  private userData: Vendor | Admin | User; // Use union type for flexibility
  private authToken: string;
  private encryptionKey = environment.encryptionKey;

  constructor() {}

  private isLocalStorageAvailable(): boolean {
    return typeof localStorage !== 'undefined';
  }

  setUserData(data: Vendor | Admin | User): void {
    if (this.isLocalStorageAvailable()) {
      const encryptedData = CryptoJS.AES.encrypt(
        JSON.stringify(data),
        this.encryptionKey
      ).toString();
      localStorage.setItem('userData', encryptedData);
    } else {
      console.log('localStorage is not available.');
    }
  }

  getUserData(): Vendor | Admin | User {
    if (this.isLocalStorageAvailable()) {
      const encryptedData = localStorage.getItem('userData');
      if (encryptedData) {
        const bytes = CryptoJS.AES.decrypt(encryptedData, this.encryptionKey);
        const decryptedData = JSON.parse(bytes.toString(CryptoJS.enc.Utf8));
        return decryptedData as Vendor | Admin | User;
      }
    } else {
      console.log('localStorage is not available.');
    }
    return null;
  }

  setAuthToken(token: string): void {
    if (this.isLocalStorageAvailable()) {
      const encryptedToken = CryptoJS.AES.encrypt(
        token,
        this.encryptionKey
      ).toString();
      localStorage.setItem('authToken', encryptedToken);
    } else {
      console.log('localStorage is not available.');
    }
  }

  getAuthToken(): string {
    if (this.isLocalStorageAvailable()) {
      const encryptedToken = localStorage.getItem('authToken');
      if (encryptedToken) {
        const bytes = CryptoJS.AES.decrypt(encryptedToken, this.encryptionKey);
        const decryptedToken = bytes.toString(CryptoJS.enc.Utf8);
        return decryptedToken;
      }
    } else {
      console.log('localStorage is not available.');
    }
    return null;
  }
}
