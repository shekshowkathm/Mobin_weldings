import { Component } from '@angular/core';
import { TopHeaderComponent } from '../top-header/top-header.component';
import { MainHeaderComponent } from '../main-header/main-header.component';
import { FooterComponent } from '../footer/footer.component';
import { MatButtonModule } from '@angular/material/button';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgIf } from '@angular/common';
import { RegisterService } from '../../service/register.service';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-contact',
  standalone: true,
  templateUrl: './contact.component.html',
  styleUrl: './contact.component.scss',
  imports: [
    TopHeaderComponent,
    MainHeaderComponent,
    FooterComponent,
    MatButtonModule,
    FormsModule,
    ReactiveFormsModule,
    NgIf,
  ],
})
export class ContactComponent {
  model: any = {
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    comments: '',
  };

  constructor(
    private registerService: RegisterService,
    private snackBar: MatSnackBar
  ) {}

  onSubmit() {
    console.log(this.model);
    this.registerService.contactPostData(this.model).subscribe({
      next: (response) => {
        console.log('Success:', response);

        this.snackBar.open('Contact Requested Successfully', 'Close', {
          duration: 3000,
          horizontalPosition: 'center',
          verticalPosition: 'bottom',
        });
      },
      error: (error) => {
        console.error('Error:', error);
        this.snackBar.open('Contact Request Failed', 'Close', {
          duration: 3000,
          horizontalPosition: 'center',
          verticalPosition: 'bottom',
        });
      },
      complete: () => {
        console.log('Request completed');
      },
    });
  }
}
