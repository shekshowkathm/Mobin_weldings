import { Component } from '@angular/core';
import { NgbCarouselModule } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-slider',
  standalone: true,
  imports: [NgbCarouselModule],
  templateUrl: './slider.component.html',
  styleUrl: './slider.component.scss',
})
export class SliderComponent {
  // images = [944, 1011, 984].map((n) => `https://picsum.photos/id/${n}/900/500`);
  images = [
    'https://firebasestorage.googleapis.com/v0/b/mobin-weldings.appspot.com/o/assets%2Fhome_slider%2F1724654046327_home_slider1.webp?alt=media&token=db2f1a2f-666c-4e12-a72c-ccf5eaee2422',
    'https://firebasestorage.googleapis.com/v0/b/mobin-weldings.appspot.com/o/assets%2Fhome_slider%2F1724654764919_home_slider2.webp?alt=media&token=c5072a95-00f3-480f-82d8-2b5e139320ae',
    'https://firebasestorage.googleapis.com/v0/b/mobin-weldings.appspot.com/o/assets%2Fhome_slider%2F1724654806549_home_slider3.webp?alt=media&token=2f25cf2f-3a43-4307-a2d6-f4d15218fadb',
    'https://firebasestorage.googleapis.com/v0/b/mobin-weldings.appspot.com/o/assets%2Fhome_slider%2F1724654879378_home_slider4.webp?alt=media&token=c38bc51c-d3c9-44cb-bcc7-f6bf16ef955d',
  ];
}
