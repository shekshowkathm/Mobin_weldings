import { Component } from '@angular/core';
import { TopHeaderComponent } from '../top-header/top-header.component';
import { MainHeaderComponent } from '../main-header/main-header.component';
import { SliderComponent } from '../slider/slider.component';
import { ExperienceComponent } from '../experience/experience.component';
import { FooterComponent } from '../footer/footer.component';

@Component({
  selector: 'app-home',
  standalone: true,
  templateUrl: './home.component.html',
  styleUrl: './home.component.scss',
  imports: [
    TopHeaderComponent,
    MainHeaderComponent,
    SliderComponent,
    ExperienceComponent,
    FooterComponent,
  ],
})
export class HomeComponent {
  ngOnInit() {
    if (this.isLocalStorageAvailable()) {
      localStorage.clear();
    } else {
      console.log('localStorage is not available.');
    }
  }

  private isLocalStorageAvailable(): boolean {
    return typeof localStorage !== 'undefined';
  }
}
