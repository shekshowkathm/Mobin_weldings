import { Component } from '@angular/core';
import { TopHeaderComponent } from "../top-header/top-header.component";
import { MainHeaderComponent } from "../main-header/main-header.component";
import { FooterComponent } from "../footer/footer.component";

@Component({
    selector: 'app-about',
    standalone: true,
    templateUrl: './about.component.html',
    styleUrl: './about.component.scss',
    imports: [TopHeaderComponent, MainHeaderComponent, FooterComponent]
})
export class AboutComponent {

}
