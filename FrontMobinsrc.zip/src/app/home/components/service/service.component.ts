import { Component } from '@angular/core';
import { TopHeaderComponent } from '../top-header/top-header.component';
import { MainHeaderComponent } from '../main-header/main-header.component';
import { FooterComponent } from '../footer/footer.component';
import { MatButtonModule } from '@angular/material/button';
import { NgFor, NgIf } from '@angular/common';

@Component({
  selector: 'app-service',
  standalone: true,
  templateUrl: './service.component.html',
  styleUrl: './service.component.scss',
  imports: [
    TopHeaderComponent,
    MainHeaderComponent,
    FooterComponent,
    MatButtonModule,
    NgIf,
    NgFor,
  ],
})
export class ServiceComponent {
  services = [
    {
      icon: 'https://firebasestorage.googleapis.com/v0/b/mobin-weldings.appspot.com/o/assets%2Fservice%2Fproduct-icon.png?alt=media&token=9e0c3a41-1d77-49f6-b859-cdf5736b5a23',
      number: '10000',
      description:
        'Find a large variety of welding and hardware products, all chosen for their quality and reliability. From welding machines to safety gear, we have everything you need.',
    },
    {
      icon: 'https://firebasestorage.googleapis.com/v0/b/mobin-weldings.appspot.com/o/assets%2Fservice%2Fvendor-icon.png?alt=media&token=342ea696-cc5a-4e7c-acfc-495f09b59ccf',
      number: '1000',
      description:
        'Buy from reliable vendors who provide the best tools and supplies. Our network ensures top-notch products that meet industry standards.',
    },
    {
      icon: 'https://firebasestorage.googleapis.com/v0/b/mobin-weldings.appspot.com/o/assets%2Fservice%2Fonline-shop-icon.png?alt=media&token=9a32ce3b-f37a-4429-bebb-341a617f95fd',
      number: '24/7',
      description:
        'Enjoy a simple and secure online shopping experience. Our user-friendly website makes it easy to browse, compare, and purchase products.',
    },
    {
      icon: 'https://firebasestorage.googleapis.com/v0/b/mobin-weldings.appspot.com/o/assets%2Fservice%2Fcustomer-service-icon.png?alt=media&token=b793ab26-adf3-4743-b678-40a6d6a49593',
      number: '24/7',
      description:
        'Get help from our friendly customer support team for any questions or issues. Our dedicated staff is here to ensure a smooth and satisfying experience..',
    },
  ];
}
