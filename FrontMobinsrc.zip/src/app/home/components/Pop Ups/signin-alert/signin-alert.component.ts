import { Component } from '@angular/core';

@Component({
  selector: 'app-signin-alert',
  standalone: true,
  imports: [],
  templateUrl: './signin-alert.component.html',
  styleUrl: './signin-alert.component.scss'
})
export class SigninAlertComponent {

}
