import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SigninAlertComponent } from './signin-alert.component';

describe('SigninAlertComponent', () => {
  let component: SigninAlertComponent;
  let fixture: ComponentFixture<SigninAlertComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SigninAlertComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SigninAlertComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
