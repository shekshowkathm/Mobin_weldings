import { NgFor, NgIf, isPlatformBrowser } from '@angular/common';
import { Component, HostListener, Inject, PLATFORM_ID } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { MatMenuModule } from '@angular/material/menu';
import { Router } from '@angular/router';
import { UserCredentialsService } from '../../service/user-credentials.service';
import { Vendor } from '../../model/vendor';
import { Admin } from '../../model/admin';
import { User } from '../../model/user';

@Component({
  selector: 'app-main-header',
  standalone: true,
  imports: [NgIf, NgFor, MatMenuModule, MatIconModule],
  templateUrl: './main-header.component.html',
  styleUrl: './main-header.component.scss',
})
export class MainHeaderComponent {
  isMobileView: boolean = false;
  authToken: string;
  public userData: any = {};

  constructor(
    @Inject(PLATFORM_ID) private platformId: Object,
    private router: Router,
    private userCredentialsService: UserCredentialsService
  ) {}

  ngOnInit() {
    this.logUserCredentials();
    if (isPlatformBrowser(this.platformId)) {
      this.checkViewportSize();
    }
  }

  @HostListener('window:resize', ['$event'])
  onResize(event: Event) {
    this.checkViewportSize();
  }

  checkViewportSize() {
    const viewportWidth = window.innerWidth;
    if (viewportWidth < 768) {
      this.onMobileView();
    }
  }

  onMobileView() {
    console.log('Mobile view activated!');
    this.isMobileView = true;
    // Call your method here
  }

  navigation(item: string) {
    if (item === 'home') {
      this.router.navigate(['/']);
    } else if (item === 'user-profile') {
      this.router.navigate(['/user/profile']);
    } else {
      this.router.navigate(['/' + item]);
    }
  }

  logUserCredentials(): void {
    this.authToken = this.userCredentialsService.getAuthToken();
    this.userData = this.userCredentialsService.getUserData();

    console.log('Auth Token:', this.authToken);
    console.log('User Data:', this.userData);
  }
}
