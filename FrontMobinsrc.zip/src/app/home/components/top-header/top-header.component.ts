import { NgFor, NgIf, isPlatformBrowser } from '@angular/common';
import { Component, HostListener, Inject, PLATFORM_ID } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { MatMenuModule } from '@angular/material/menu';

@Component({
  selector: 'app-top-header',
  standalone: true,
  imports: [MatIconModule, NgIf, NgFor, MatMenuModule],
  templateUrl: './top-header.component.html',
  styleUrl: './top-header.component.scss',
})
export class TopHeaderComponent {
  phoneNumber: string = '1234-5678-9026';
  email: string = 'support@welderpro.com';

  isMobileView: boolean = false;

  constructor(@Inject(PLATFORM_ID) private platformId: Object) {}

  ngOnInit() {
    if (isPlatformBrowser(this.platformId)) {
      this.checkViewportSize();
    }
  }

  @HostListener('window:resize', ['$event'])
  onResize(event: Event) {
    this.checkViewportSize();
  }

  checkViewportSize() {
    const viewportWidth = window.innerWidth;
    if (viewportWidth < 768) {
      this.onMobileView();
    }
    
  }

  onMobileView() {
    console.log('Mobile view activated!');
    this.isMobileView = true;
    // Call your method here
  }
}
