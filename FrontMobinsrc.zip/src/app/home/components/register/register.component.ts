import { Component } from '@angular/core';
import { TopHeaderComponent } from '../top-header/top-header.component';
import { MainHeaderComponent } from '../main-header/main-header.component';
import { FooterComponent } from '../footer/footer.component';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { FormsModule, NgForm, ReactiveFormsModule } from '@angular/forms';
import { NgFor, NgIf } from '@angular/common';
import { Router } from '@angular/router';
import { RegisterService } from '../../service/register.service';
import { HttpClient } from '@angular/common/http';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-register',
  standalone: true,
  templateUrl: './register.component.html',
  styleUrl: './register.component.scss',
  imports: [
    TopHeaderComponent,
    MainHeaderComponent,
    FooterComponent,
    MatIconModule,
    MatButtonModule,
    ReactiveFormsModule,
    FormsModule,
    NgIf,
    NgFor,
    MatProgressSpinnerModule,
  ],
})
export class RegisterComponent {
  today: string;
  showLoader: boolean = false;

  constructor(
    private router: Router,
    private registerService: RegisterService,
    private snackBar: MatSnackBar
  ) {
    const today = new Date();
    this.today = today.toISOString().split('T')[0]; // Format the date to yyyy-mm-dd
  }

  onSubmit(registerForm: NgForm): void {
    if (registerForm.valid) {
      this.showLoader = true;
      if (registerForm.value.password !== registerForm.value.confirmPassword) {
        registerForm.controls['confirmPassword'].setErrors({ mismatch: true });
      } else {
        console.log('Form Submitted!', registerForm.value);
        this.registerService.registerPostData(registerForm.value).subscribe({
          next: (response) => {
            this.showLoader = false;
            console.log('Success:', response);
            this.snackBar.open('Login successful', 'Close', {
              duration: 3000,
              horizontalPosition: 'center',
              verticalPosition: 'bottom',
            });
          },
          error: (error) => {
            this.showLoader = false;
            console.error('Error:', error);
            this.snackBar.open('Login failed', 'Close', {
              duration: 3000,
              horizontalPosition: 'center',
              verticalPosition: 'bottom',
            });
          },
          complete: () => {
            console.log('Request completed');
          },
        });
      }
    }
  }

  validatePasswords(registerForm: NgForm): void {
    if (registerForm.value.password !== registerForm.value.confirmPassword) {
      registerForm.controls['confirmPassword'].setErrors({ mismatch: true });
    }
  }

  navigateToLogin() {
    this.router.navigate(['/login']);
  }
}
