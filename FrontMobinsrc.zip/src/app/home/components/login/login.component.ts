import { Component } from '@angular/core';
import { TopHeaderComponent } from '../top-header/top-header.component';
import { MainHeaderComponent } from '../main-header/main-header.component';
import { FooterComponent } from '../footer/footer.component';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { FormsModule, NgForm, ReactiveFormsModule } from '@angular/forms';
import { NgFor, NgIf } from '@angular/common';
import { Router } from '@angular/router';
import { RegisterService } from '../../service/register.service';
import { ProgressBarModule } from 'primeng/progressbar';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { MessageService } from 'primeng/api';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { UserCredentialsService } from '../../service/user-credentials.service';
import { Vendor } from '../../model/vendor';
import { User } from '../../model/user';
import { Admin } from '../../model/admin';

@Component({
  selector: 'app-login',
  standalone: true,
  templateUrl: './login.component.html',
  styleUrl: './login.component.scss',
  imports: [
    TopHeaderComponent,
    MainHeaderComponent,
    FooterComponent,
    MatIconModule,
    MatButtonModule,
    ReactiveFormsModule,
    FormsModule,
    NgIf,
    NgFor,
    ProgressBarModule,
    ProgressSpinnerModule,
    MatProgressSpinnerModule,
  ],
})
export class LoginComponent {
  showLoader: boolean = false;

  constructor(
    private router: Router,
    private registerService: RegisterService,
    private snackBar: MatSnackBar,
    private userCredentialsService: UserCredentialsService
  ) {}

  onSubmit(loginForm: NgForm): void {
    if (loginForm.valid) {
      console.log('Form Submitted!', loginForm.value);
      this.showLoader = true;
      this.registerService.loginPostData(loginForm.value).subscribe({
        next: (response) => {
          console.log(response);

          this.showLoader = false;
          if (response.Data.role === 'User') {
            this.router.navigate(['/products/search']);
          } else if (response.Data.role === 'Vendor') {
            this.router.navigate(['/vendor/products']);
          } else if (response.Data.role === 'Admin') {
          }

          console.log('Success:', response);

          this.processLoginResponse(response);

          this.snackBar.open('Login successful', 'Close', {
            duration: 3000,
            horizontalPosition: 'center',
            verticalPosition: 'bottom',
          });
        },
        error: (error) => {
          this.showLoader = false;
          console.error('Error:', error);
          this.snackBar.open('Login failed', 'Close', {
            duration: 3000,
            horizontalPosition: 'center',
            verticalPosition: 'bottom',
          });
        },
        complete: () => {
          console.log('Request completed');
        },
      });
    }
  }

  navigateToRegister() {
    this.router.navigate(['/register']);
  }

  private processLoginResponse(response: any): void {
    switch (response.Data.role) {
      case 'Vendor':
        const vendorData: Vendor = this.mapVendorData(response.Data);
        this.userCredentialsService.setUserData(vendorData);
        break;
      case 'Admin':
        const adminData: Admin = this.mapAdminData(response.Data);
        this.userCredentialsService.setUserData(adminData);
        break;
      case 'User':
        const userData: User = this.mapUserData(response.Data);
        this.userCredentialsService.setUserData(userData);
        break;
      default:
        console.warn('Unknown role:', response.Data.role);
        break;
    }

    this.userCredentialsService.setAuthToken(response.Token);
  }

  private mapVendorData(data: any): Vendor {
    return {
      vendor_id: data.vendor_id,
      unique_vendor_id: data.unique_vendor_id,
      name: data.name,
      email: data.email,
      phone: data.phone,
      address: data.address,
      created_at: new Date(data.created_at),
      updated_at: new Date(data.updated_at),
      is_active: data.is_active,
      role: data.role,
      is_verified: data.is_verified,
    };
  }

  private mapAdminData(data: any): Admin {
    return {
      admin_id: data.admin_id,
      unique_admin_id: data.unique_admin_id,
      name: data.name,
      email: data.email,
      phone: data.phone,
      address: data.address,
      created_at: new Date(data.created_at),
      updated_at: new Date(data.updated_at),
      is_active: data.is_active,
      role: data.role,
      is_verified: data.is_verified,
    };
  }

  private mapUserData(data: any): User {
    return {
      user_id: data.user_id,
      user_unique_id: data.user_unique_id,
      name: data.name,
      email: data.email,
      phone: data.phone,
      gender: data.gender,
      address: data.address,
      created_at: new Date(data.created_at),
      updated_at: new Date(data.updated_at),
      is_active: data.is_active,
      role: data.role,
      is_verified: data.is_verified,
    };
  }
}
