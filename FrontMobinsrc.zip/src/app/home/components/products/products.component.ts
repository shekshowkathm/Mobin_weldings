import { Component } from '@angular/core';
import { TopHeaderComponent } from '../top-header/top-header.component';
import { MainHeaderComponent } from '../main-header/main-header.component';
import { FooterComponent } from '../footer/footer.component';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { NgFor, NgForOf, NgIf } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';

import { MatDialog } from '@angular/material/dialog';
import { ConfirmPopupModule } from 'primeng/confirmpopup';
import { ConfirmationService } from 'primeng/api';

import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { ButtonModule } from 'primeng/button';
import { Router } from '@angular/router';

interface Product {
  name: string;
  description: string;
  price: number;
  category: string;
  imageurl: string;
  is_available: boolean;
  free_delivery: boolean;
}

@Component({
  selector: 'app-products',
  standalone: true,
  templateUrl: './products.component.html',
  styleUrl: './products.component.scss',
  imports: [
    TopHeaderComponent,
    MainHeaderComponent,
    FooterComponent,
    MatCardModule,
    MatButtonModule,
    NgIf,
    NgFor,
    NgForOf,
    MatIconModule,
    ConfirmPopupModule,
    ConfirmDialogModule,
    ButtonModule,
  ],
  providers: [ConfirmationService],
})
export class ProductsComponent {
  products: Product[] = [
    {
      name: 'Mobin Weldings',
      description: "G-Shock Digital Black Dial Unisex's Watch-DW-5610SU-...",
      price: 7995,
      category: 'gates',
      imageurl:
        'https://mulhollandbrand.com/wp-content/uploads/2021/05/2a-4.jpg',
      is_available: true,
      free_delivery: true,
    },
    {
      name: 'Shaun Grill Works',
      description:
        "G-Shock Digital Gold Dial Men's Watch - GD-100GB-1DR (G340)",
      price: 6595,
      category: 'grill',
      imageurl:
        'https://i.pinimg.com/736x/f0/a1/b7/f0a1b75446e5f6bc22b5a28181ed1e0d.jpg',
      is_available: false,
      free_delivery: false,
    },
    {
      name: 'Mobin Weldings',
      description: "G-Shock Digital Black Dial Unisex's Watch-DW-5610SU-...",
      price: 7995,
      category: 'gates',
      imageurl:
        'https://mulhollandbrand.com/wp-content/uploads/2021/05/2a-4.jpg',
      is_available: true,
      free_delivery: true,
    },
    {
      name: 'Shaun Grill Works',
      description:
        "G-Shock Digital Gold Dial Men's Watch - GD-100GB-1DR (G340)",
      price: 6595,
      category: 'grill',
      imageurl:
        'https://i.pinimg.com/736x/f0/a1/b7/f0a1b75446e5f6bc22b5a28181ed1e0d.jpg',
      is_available: false,
      free_delivery: false,
    },
    // Add more products here
  ];

  showModal: boolean = false;
  constructor(
    public dialog: MatDialog,
    private confirmationService: ConfirmationService,
    private router: Router
  ) {}

  signInPop(event: Event) {
    this.confirmationService.confirm({
      target: event.target as EventTarget,
      message: 'To know more info you need to sign in',
      header: 'Sign in now!',
      icon: 'pi pi-exclamation-triangle',
      acceptIcon: 'none',
      acceptButtonStyleClass: 'p-button p-component',
      acceptLabel: 'Sign in',
      accept: () => {
        this.router.navigate(['/login']);

        // this.messageService.add({ severity: 'info', summary: 'Confirmed', detail: 'You have accepted' });
      },
      rejectVisible: false,
    });
  }
}
