import {
  HttpClient,
  HttpErrorResponse,
  HttpHeaders,
} from '@angular/common/http';
import { Injectable } from '@angular/core';
import { UserCredentialsService } from '../../home/service/user-credentials.service';
import { catchError, Observable, throwError } from 'rxjs';
import { environment } from '../../../environments/environment.development';

@Injectable({
  providedIn: 'root',
})
export class ProfileService {
  public addAddressAPIForUser = environment.localdomain + 'api/addressregister';
  public sendEmailOTPAPI = environment.localdomain + 'api/sendotptouser/';
  public updateAddressAPIForUser =
    environment.localdomain + 'api/updateaddressbyaddressuniqueid/';
  public getAllAddressAPIForUser =
    environment.localdomain + 'api/getaddressbyuseruniqueid/';
  public deleteAddressAPIForUser =
    environment.localdomain + 'api/deleteaddressbyaddressuniqueid/';
  public updatePersonalInfoAPI =
    environment.localdomain + 'api/updateuserprofile/';
  public userPasswordUpdateAPI =
    environment.localdomain + 'api/userpasswordupdate/';

  constructor(
    private http: HttpClient,
    private userService: UserCredentialsService
  ) {}

  private getRequestOptions(): { headers: HttpHeaders } {
    const token = this.userService.getAuthToken(); // Ensure getAuthToken is called correctly
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
    });
    return { headers };
  }

  private handleError(error: HttpErrorResponse): Observable<never> {
    let errorMessage = 'Something went wrong; please try again later.';

    if (error.error instanceof ErrorEvent) {
      // Client-side error
      console.error('An error occurred:', error.error.message);
      errorMessage = `Client-side error: ${error.error.message}`;
    } else {
      // Server-side error
      console.error(
        `Backend returned code ${error.status}, ` + `body was: ${error.error}`
      );
      errorMessage = `Server-side error: ${error.status} ${error.message}`;
    }

    // Return an observable with a user-facing error message
    return throwError(() => new Error(errorMessage));
  }

  addAddressForUser(data) {
    const requestOptions = this.getRequestOptions();
    return this.http
      .post<any>(this.addAddressAPIForUser, data, requestOptions)
      .pipe(catchError(this.handleError));
  }
  putAddressForUser(data, address_unique_id) {
    const requestOptions = this.getRequestOptions();
    return this.http
      .put<any>(
        this.updateAddressAPIForUser + address_unique_id,
        data,
        requestOptions
      )
      .pipe(catchError(this.handleError));
  }

  getAllAddressForUser(user_unique_id): Observable<any> {
    const requestOptions = this.getRequestOptions();
    return this.http
      .get<any>(this.getAllAddressAPIForUser + user_unique_id, requestOptions)
      .pipe(
        catchError(this.handleError) // Error handling
      );
  }

  deleteAddressForUser(address_unique_id): Observable<any> {
    const requestOptions = this.getRequestOptions();
    return this.http
      .delete<any>(
        this.deleteAddressAPIForUser + address_unique_id,
        requestOptions
      )
      .pipe(
        catchError(this.handleError) // Error handling
      );
  }

  putPersonalInfoForUser(data, user_unique_id) {
    const requestOptions = this.getRequestOptions();
    return this.http
      .put<any>(
        this.updatePersonalInfoAPI + user_unique_id,
        data,
        requestOptions
      )
      .pipe(catchError(this.handleError));
  }

  sendOTPUsingMail(email) {
    const requestOptions = this.getRequestOptions();
    return this.http
      .post<any>(this.sendEmailOTPAPI + email, '', requestOptions)
      .pipe(catchError(this.handleError));
  }

  passwordUpdateForUser(data) {
    const requestOptions = this.getRequestOptions();
    return this.http
      .put<any>(this.userPasswordUpdateAPI, data, requestOptions)
      .pipe(catchError(this.handleError));
  }
}
