import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ProfileComponent } from './components/profile/profile.component';
import { FormsComponent } from './components/forms/forms.component';

const routes: Routes = [
  { path: 'profile', component: ProfileComponent },
  { path: 'forms', component: FormsComponent },

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class UserRoutingModule { }
