import { NgFor, NgIf } from '@angular/common';
import { ChangeDetectorRef, Component, NgZone } from '@angular/core';
import { FormsModule, NgForm, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { UserCredentialsService } from '../../../home/service/user-credentials.service';
import { ProfileService } from '../../service/profile.service';
import { error } from 'console';
import { interval, Subscription, takeWhile } from 'rxjs';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { Router } from '@angular/router';

@Component({
  selector: 'app-reset-password',
  standalone: true,
  imports: [
    FormsModule,
    ReactiveFormsModule,
    MatIconModule,
    MatButtonModule,
    NgIf,
    NgFor,
    MatSnackBarModule,
  ],
  templateUrl: './reset-password.component.html',
  styleUrl: './reset-password.component.scss',
})
export class ResetPasswordComponent {
  userEmail: string = '';
  userOTP: number | null = null;
  backEndOTP: number;
  passwordsMatch: boolean = true;

  authToken: string;
  public userData: any;

  remainingTime: number = 0;
  private countdownSubscription: Subscription | null = null;

  showEmailForm: boolean = true;
  showOTPForm: boolean;
  showPassword: boolean;

  constructor(
    private userCredentialsService: UserCredentialsService,
    private profileService: ProfileService,
    private cdr: ChangeDetectorRef,
    private snackBar: MatSnackBar,
    private router: Router
  ) {}

  ngOnInit() {
    this.logUserCredentials();
  }

  logUserCredentials(): void {
    this.authToken = this.userCredentialsService.getAuthToken();
    this.userData = this.userCredentialsService.getUserData();
    this.userEmail = this.userData.email;
  }

  sendOTP() {
    console.log(this.userEmail);
    this.profileService.sendOTPUsingMail(this.userEmail).subscribe({
      next: (response) => {
        // console.log(response);
        this.backEndOTP = response.OTP;
        // console.log(this.backEndOTP);
        this.showEmailForm = false;
        this.showOTPForm = true;
        this.startCountdown(60);
        this.cdr.detectChanges();
      },
      error: (error) => {
        console.log(error);
      },
    });
  }

  startCountdown(seconds: number): void {
    this.remainingTime = seconds;

    // Unsubscribe from any previous countdown to prevent multiple subscriptions
    if (this.countdownSubscription) {
      this.countdownSubscription.unsubscribe();
    }

    const countdown$ = interval(1000).pipe(
      takeWhile(() => this.remainingTime > 0)
    );

    this.countdownSubscription = countdown$.subscribe(() => {
      this.remainingTime--;
      this.cdr.detectChanges(); // Manually trigger change detection
      if (this.remainingTime === 0) {
        this.otpTimeUP();
      }
    });
  }

  otpTimeUP(): void {
    console.log('OTP time is up!');
    // Your logic here, e.g., allow the user to resend the OTP
  }

  resendOTP() {
    if (this.countdownSubscription) {
      this.countdownSubscription.unsubscribe();
      this.remainingTime = 0;
    }
    this.backEndOTP = 0;
    this.showEmailForm = true;
    this.showOTPForm = false;
  }

  submitOTP() {
    if (this.userOTP !== null && /^[0-9]{6}$/.test(this.userOTP.toString())) {
      // console.log('Backend OTP ', this.backEndOTP);

      // console.log('OTP Submitted:', this.userOTP);

      if (this.backEndOTP == this.userOTP) {
        console.log('OTP matched');
        this.snackBar.open('OTP verified', 'Close', {
          duration: 3000,
          horizontalPosition: 'center',
          verticalPosition: 'top',
        });
        this.backEndOTP = 0;
        this.showEmailForm = false;
        this.showOTPForm = false;
        this.showPassword = true;
      } else {
        console.log('OTP not matched');
        this.snackBar.open('Invalid OTP', 'Close', {
          duration: 3000,
          horizontalPosition: 'center',
          verticalPosition: 'top',
        });
        this.backEndOTP = 0;
        this.showEmailForm = true;
        this.showOTPForm = false;
      }
    }
  }

  validatePasswords(password: string, confirmPassword: string) {
    this.passwordsMatch = password === confirmPassword;
  }

  passwordSubmit(form: NgForm) {
    // Ensure validation for both fields before submission
    if (form.valid && this.passwordsMatch) {
      // Handle the form submission logic here
      // console.log('Form Submitted!', form.value);
      const passwordBody = {
        email: this.userData.email,
        password: form.value.password,
      };
      console.log(passwordBody);
      this.profileService.passwordUpdateForUser(passwordBody).subscribe({
        next: (response) => {
          console.log(response);
          this.router.navigate(['/']);

          this.cdr.detectChanges();
        },
        error: (error) => {
          console.log(error);
        },
      });
    } else {
      console.log('Form is invalid or passwords do not match.');
    }
  }
}
