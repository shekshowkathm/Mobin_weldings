import {
  Component,
  ChangeDetectionStrategy,
  signal,
  ChangeDetectorRef,
  ViewChild,
} from '@angular/core';
import { TopHeaderComponent } from '../../../home/components/top-header/top-header.component';
import { MainHeaderComponent } from '../../../home/components/main-header/main-header.component';
import { FooterComponent } from '../../../home/components/footer/footer.component';
import {
  MatExpansionModule,
  MatExpansionPanel,
} from '@angular/material/expansion';
import { MatCardModule } from '@angular/material/card';
import { Router } from '@angular/router';
import { UserCredentialsService } from '../../../home/service/user-credentials.service';
import { Vendor } from '../../../home/model/vendor';
import { Admin } from '../../../home/model/admin';
import { User } from '../../../home/model/user';
import { NgClass, NgFor, NgIf } from '@angular/common';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatButtonModule } from '@angular/material/button';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { MatMenuModule } from '@angular/material/menu';
import { MatDialog } from '@angular/material/dialog';
import { AddressComponent } from '../Dialog/address/address.component';
import { MatRadioModule } from '@angular/material/radio';
import { ProfileService } from '../../service/profile.service';
import { MatTooltipModule } from '@angular/material/tooltip';
import { ResetPasswordComponent } from "../reset-password/reset-password.component";

@Component({
  selector: 'app-profile',
  standalone: true,
  imports: [
    TopHeaderComponent,
    MainHeaderComponent,
    FooterComponent,
    MatExpansionModule,
    MatCardModule,
    NgIf,
    NgFor,
    MatSlideToggleModule,
    MatButtonModule,
    NgClass,
    FormsModule,
    ReactiveFormsModule,
    MatIconModule,
    MatMenuModule,
    MatRadioModule,
    MatTooltipModule,
    ResetPasswordComponent
],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './profile.component.html',
  styleUrl: './profile.component.scss',
})
export class ProfileComponent {
  readonly panelOpenState = signal(false);

  authToken: string;
  public userData: any;
  mode: string = 'Cancel';
  showAddressForm: boolean = false;

  userAddress: any[] = [];

  addressFormData = {
    name: '',
    address_type: '',
    address_line: '',
    locality: '',
    landmark: '',
    district: '',
    state: '',
    pincode: '',
    phone_number: '',
    address_unique_id: '',
    user_unique_id: '',
  };

  addressTitle: string = '';

  @ViewChild('profilePanel') profilePanel: MatExpansionPanel;
  @ViewChild('addressPanel') addressPanel: MatExpansionPanel;
  @ViewChild('passwordPanel') passwordPanel: MatExpansionPanel;

  constructor(
    private router: Router,
    private userCredentialsService: UserCredentialsService,
    private profileService: ProfileService,
    public dialog: MatDialog,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit() {
    this.logUserCredentials();
    this.getUserAddressByUniqueID();
  }

  logUserCredentials(): void {
    console.log(this.userCredentialsService.getUserData());

    this.authToken = this.userCredentialsService.getAuthToken();
    this.userData = this.userCredentialsService.getUserData();

    console.log('Auth Token:', this.authToken);
    console.log('User Data:', this.userData);
  }

  /***
   *
   * Panel Toggles methods
   *
   * **/

  toggleProfilePanel(): void {
    if (this.profilePanel.expanded) {
      this.profilePanel.close();
    } else {
      this.profilePanel.open();
    }
  }
  toggleAddressPanel(): void {
    if (this.addressPanel.expanded) {
      this.addressPanel.close();
    } else {
      this.addressPanel.open();
    }
  }
  togglePasswordPanel(): void {
    if (this.passwordPanel.expanded) {
      this.passwordPanel.close();
    } else {
      this.passwordPanel.open();
    }
  }

  onSubmit(form: any, mode): void {
    if (form.valid) {
      console.log('Form Submitted!', form.value);
      console.log(mode);

      this.profileService
        .putPersonalInfoForUser(form.value, this.userData.user_unique_id)
        .subscribe({
          next: (response) => {
            console.log(response);
            const userData: User = this.mapUserData(response.Data);
            this.userCredentialsService.setUserData(userData);
            this.userData = this.userCredentialsService.getUserData();
            this.mode = 'Cancel';
            this.cdr.detectChanges();
          },
          error: (error) => {
            console.log(error);
          },
        });
    }
  }

  changeMode(mode: string) {
    if (mode === 'Edit') {
      this.mode = 'Cancel';
    } else {
      this.mode = 'Edit';
    }
  }

  addNewAddress() {
    this.addressTitle = 'Add New Address';
    this.showAddressForm = true;
  }
  closeAddressForm() {
    this.showAddressForm = false;
  }

  getUserAddressByUniqueID() {
    this.profileService
      .getAllAddressForUser(this.userData.user_unique_id)
      .subscribe({
        next: (response) => {
          console.log(response);
          this.userAddress = response.Data;
          this.cdr.detectChanges();
        },
        error: (error) => {
          console.log(error);
        },
      });
  }

  updateOneAddress(address) {
    this.addressTitle = 'Update Your Address';
    this.showAddressForm = true;
    console.log(address);
    this.addressFormData = {
      name: address.name,
      address_type: address.address_type,
      address_line: address.address_line,
      locality: address.locality,
      landmark: address.landmark,
      district: address.district,
      state: address.state,
      pincode: address.pincode,
      phone_number: address.phone_number,
      address_unique_id: address.address_unique_id,
      user_unique_id: this.userData.user_unique_id,
    };
  }

  deleteOneAddress(address_unique_id) {
    this.profileService.deleteAddressForUser(address_unique_id).subscribe({
      next: (response) => {
        console.log(response);
        this.getUserAddressByUniqueID();
        this.cdr.detectChanges();
      },
      error: (error) => {
        console.log(error);
      },
    });
  }

  addressFeed(formData: any) {
    if (formData.valid) {
      console.log('Form Submitted!', this.addressFormData);

      if (this.addressTitle === 'Add New Address') {
        this.addressFormData.address_unique_id = '';
        this.addressFormData.user_unique_id = this.userData.user_unique_id;

        this.profileService.addAddressForUser(this.addressFormData).subscribe({
          next: (response) => {
            console.log(response);
            this.getUserAddressByUniqueID();
            this.showAddressForm = false;
            this.addressFormData = {
              name: '',
              address_type: '',
              address_line: '',
              locality: '',
              landmark: '',
              district: '',
              state: '',
              pincode: '',
              phone_number: '',
              address_unique_id: '',
              user_unique_id: this.userData.user_unique_id,
            };
            this.cdr.detectChanges();
          },
          error: (error) => {
            console.log(error);
          },
        });
      } else {
        delete this.addressFormData.user_unique_id;
        console.log('update things', this.addressFormData);
        formData.value.user_unique_id = Number(this.userData.user_unique_id);
        this.profileService
          .putAddressForUser(
            this.addressFormData,
            this.addressFormData.address_unique_id
          )
          .subscribe({
            next: (response) => {
              console.log(response);
              this.getUserAddressByUniqueID();
              this.showAddressForm = false;
              this.addressFormData = {
                name: '',
                address_type: '',
                address_line: '',
                locality: '',
                landmark: '',
                district: '',
                state: '',
                pincode: '',
                phone_number: '',
                address_unique_id: '',
                user_unique_id: this.userData.user_unique_id,
              };
              this.cdr.detectChanges();
            },
            error: (error) => {
              console.log(error);
            },
          });
      }
    } else {
      console.log('Form is invalid!');
    }
  }

  private mapUserData(data: any): User {
    return {
      user_id: data.user_id,
      user_unique_id: data.user_unique_id,
      name: data.name,
      email: data.email,
      phone: data.phone,
      gender: data.gender,
      address: data.address,
      created_at: new Date(data.created_at),
      updated_at: new Date(data.updated_at),
      is_active: data.is_active,
      role: data.role,
      is_verified: data.is_verified,
    };
  }
}
