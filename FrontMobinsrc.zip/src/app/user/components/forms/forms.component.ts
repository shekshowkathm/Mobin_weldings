import { NgFor, NgIf } from '@angular/common';
import { Component } from '@angular/core';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';

@Component({
  selector: 'app-forms',
  standalone: true,
  imports: [NgIf, ReactiveFormsModule, FormsModule, NgFor],
  templateUrl: './forms.component.html',
  styleUrl: './forms.component.scss'
})
export class FormsComponent {

  userInfo = {
    name: "Shek",
    city: "TVM",
    email: "shek@gmail.com",
    Phone: "+91 9787583847"
  }

  userform: FormGroup;

  userArray = [
    { id: 1, name: "John Doe", email: "john.doe@example.com", country: "USA", age: 28 },
    { id: 2, name: "Jane Smith", email: "jane.smith@example.com", country: "UK", age: 32 },
    { id: 3, name: "Rahul Sharma", email: "rahul.sharma@example.com", country: "India", age: 26 },
    { id: 4, name: "Emily Johnson", email: "emily.johnson@example.com", country: "Canada", age: 30 },
    { id: 5, name: "Carlos Rodriguez", email: "carlos.rodriguez@example.com", country: "Mexico", age: 35 },
    { id: 6, name: "Samantha Lee", email: "samantha.lee@example.com", country: "Australia", age: 27 },
    { id: 7, name: "Liam O'Brien", email: "liam.obrien@example.com", country: "Ireland", age: 29 },
    { id: 8, name: "Chen Wei", email: "chen.wei@example.com", country: "China", age: 31 },
    { id: 9, name: "Aisha Khan", email: "aisha.khan@example.com", country: "Pakistan", age: 24 },
    { id: 10, name: "David Miller", email: "david.miller@example.com", country: "Germany", age: 33 }
  ];

  filterredArray: any[] = []


  userTypes: string = ''

  constructor(private fb: FormBuilder) {
    this.formInitializer();
  }

  ngOnInit() {
    console.log("Forms Init");
    this.checkEmailKey();
    this.filterredArray = this.userArray
    
    console.log(this.sumArrayElements([1,5,8,6,7,3,1]));
    
  }

  formInitializer() {
    this.userform = this.fb.group({
      name: ['', [Validators.required, Validators.minLength(3)]],
      email: ['', [Validators.required, Validators.pattern("^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$")]],
      country: ['', [Validators.required]]
    });
  }


  checkEmailKey() {
    if ("email" in this.userInfo) {
      console.log("Email is present");

    } else {
      console.log("email key is missing");

    }
  }


  getFormControl(formcontrolname: string) {
    return this.userform.get(formcontrolname)
  }

  submitUserForm() {
    if (this.userform.valid) {
      console.log(this.userform.value);

    } else {
      console.log('Form is invalid');

    }
  }

  userInput() {
    console.log("User entered:", this.userTypes);
    if (this.userTypes) {
      // this.userArray = this.userArray.filter((items) => items.name.toLowerCase().includes(this.userTypes) || items.email.toLowerCase().includes(this.userTypes) || items.country.toLowerCase().includes(this.userTypes));
      // this.userArray = this.userArray.filter((item) =>

      //   Object.values(item).some((value) => value.toString().toLowerCase().includes(this.userTypes))
      // )
      this.filterredArray = this.userArray.filter((item) =>
        Object.values(item).some(value => value.toString().toLowerCase().includes(this.userTypes))
      )
    } else {
      this.filterredArray = this.userArray
    }
  }

  sumArrayElements(array: number[]) {

    return array.reduce((sum, value) => sum + value, 0)
  }

}
