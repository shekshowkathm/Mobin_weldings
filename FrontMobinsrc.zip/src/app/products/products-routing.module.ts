import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ProductSearchComponent } from './components/product-search/product-search.component';
import { CategorizedProductsComponent } from './components/categorized-products/categorized-products.component';

const routes: Routes = [
  { path: 'search', component: ProductSearchComponent },
  { path: 'categorizedproducts/:category/:subCategory', component: CategorizedProductsComponent },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ProductsRoutingModule {}
