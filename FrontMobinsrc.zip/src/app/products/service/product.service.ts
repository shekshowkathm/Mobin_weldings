import { Injectable } from '@angular/core';
import { UserCredentialsService } from '../../home/service/user-credentials.service';
import {
  HttpClient,
  HttpErrorResponse,
  HttpHeaders,
} from '@angular/common/http';
import { BehaviorSubject, catchError, Observable, throwError } from 'rxjs';
import { environment } from '../../../environments/environment.development';

@Injectable({
  providedIn: 'root',
})
export class ProductService {
  public categoryGetAllAPI = environment.localdomain + 'api/getallcategory';
  public categoryWiseSearchAPI =
    environment.localdomain + 'api/getproductsbycategoryandsubcategory';

  private productDataSource = new BehaviorSubject<any[]>([]);
  productsData = this.productDataSource.asObservable();

  constructor(
    private http: HttpClient,
    private userService: UserCredentialsService
  ) {}

  private getRequestOptions(): { headers: HttpHeaders } {
    const token = this.userService.getAuthToken(); // Ensure getAuthToken is called correctly
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
    });
    return { headers };
  }

  // Error handling method
  private handleError(error: HttpErrorResponse): Observable<never> {
    let errorMessage = 'Something went wrong; please try again later.';

    if (error.error instanceof ErrorEvent) {
      // Client-side error
      console.error('An error occurred:', error.error.message);
      errorMessage = `Client-side error: ${error.error.message}`;
    } else {
      // Server-side error
      console.error(
        `Backend returned code ${error.status}, ` + `body was: ${error.error}`
      );
      errorMessage = `Server-side error: ${error.status} ${error.message}`;
    }

    // Return an observable with a user-facing error message
    return throwError(() => new Error(errorMessage));
  }

  getAllCategoryData(): Observable<any> {
    const requestOptions = this.getRequestOptions();

    return this.http.get<any>(this.categoryGetAllAPI, requestOptions).pipe(
      catchError(this.handleError) // Error handling
    );
  }

  categoryAndSubcategorySearch(data) {
    const requestOptions = this.getRequestOptions();
    return this.http
      .post<any>(this.categoryWiseSearchAPI, data, requestOptions)
      .pipe(catchError(this.handleError));
  }

  changeProductsData(data: any[]) {
    this.productDataSource.next(data);
  }
}
