import { Component } from '@angular/core';
import { TopHeaderComponent } from '../../../home/components/top-header/top-header.component';
import { MainHeaderComponent } from '../../../home/components/main-header/main-header.component';
import { FooterComponent } from '../../../home/components/footer/footer.component';
import { FormControl, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { map, Observable, startWith } from 'rxjs';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { AsyncPipe, NgFor, NgIf } from '@angular/common';

import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatIconModule } from '@angular/material/icon';

import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { UserCredentialsService } from '../../../home/service/user-credentials.service';
import { ProductService } from '../../service/product.service';
import { Router } from '@angular/router';

interface Product {
  name: string;
  description: string;
  price: number;
  category: string;
  imageurl: string;
  is_available: boolean;
  free_delivery: boolean;
}

@Component({
  selector: 'app-product-search',
  standalone: true,
  imports: [
    TopHeaderComponent,
    MainHeaderComponent,
    FooterComponent,
    FormsModule,
    MatAutocompleteModule,
    AsyncPipe,
    MatFormFieldModule,
    ReactiveFormsModule,
    MatInputModule,
    NgIf,
    NgFor,
    MatIconModule,
    MatCardModule,
    MatButtonModule,
  ],
  templateUrl: './product-search.component.html',
  styleUrl: './product-search.component.scss',
})
export class ProductSearchComponent {
  myControl = new FormControl();
  options: string[] = ['One', 'Two', 'Three', 'on'];
  filteredOptions: string[];

  categoryData: any[] = [];

  products: Product[] = [
    {
      name: 'Mobin Weldings',
      description: "G-Shock Digital Black Dial Unisex's Watch-DW-5610SU-...",
      price: 7995,
      category: 'gates',
      imageurl:
        'https://mulhollandbrand.com/wp-content/uploads/2021/05/2a-4.jpg',
      is_available: true,
      free_delivery: true,
    },
    {
      name: 'Shaun Grill Works',
      description:
        "G-Shock Digital Gold Dial Men's Watch - GD-100GB-1DR (G340)",
      price: 6595,
      category: 'grill',
      imageurl:
        'https://i.pinimg.com/736x/f0/a1/b7/f0a1b75446e5f6bc22b5a28181ed1e0d.jpg',
      is_available: false,
      free_delivery: false,
    },
    {
      name: 'Mobin Weldings',
      description: "G-Shock Digital Black Dial Unisex's Watch-DW-5610SU-...",
      price: 7995,
      category: 'gates',
      imageurl:
        'https://mulhollandbrand.com/wp-content/uploads/2021/05/2a-4.jpg',
      is_available: true,
      free_delivery: true,
    },
    {
      name: 'Shaun Grill Works',
      description:
        "G-Shock Digital Gold Dial Men's Watch - GD-100GB-1DR (G340)",
      price: 6595,
      category: 'grill',
      imageurl:
        'https://i.pinimg.com/736x/f0/a1/b7/f0a1b75446e5f6bc22b5a28181ed1e0d.jpg',
      is_available: false,
      free_delivery: false,
    },
    {
      name: 'Mobin Weldings',
      description: "G-Shock Digital Black Dial Unisex's Watch-DW-5610SU-...",
      price: 7995,
      category: 'gates',
      imageurl:
        'https://mulhollandbrand.com/wp-content/uploads/2021/05/2a-4.jpg',
      is_available: true,
      free_delivery: true,
    },
    {
      name: 'Shaun Grill Works',
      description:
        "G-Shock Digital Gold Dial Men's Watch - GD-100GB-1DR (G340)",
      price: 6595,
      category: 'grill',
      imageurl:
        'https://i.pinimg.com/736x/f0/a1/b7/f0a1b75446e5f6bc22b5a28181ed1e0d.jpg',
      is_available: false,
      free_delivery: false,
    },
    {
      name: 'Mobin Weldings',
      description: "G-Shock Digital Black Dial Unisex's Watch-DW-5610SU-...",
      price: 7995,
      category: 'gates',
      imageurl:
        'https://mulhollandbrand.com/wp-content/uploads/2021/05/2a-4.jpg',
      is_available: true,
      free_delivery: true,
    },
    {
      name: 'Shaun Grill Works',
      description:
        "G-Shock Digital Gold Dial Men's Watch - GD-100GB-1DR (G340)",
      price: 6595,
      category: 'grill',
      imageurl:
        'https://i.pinimg.com/736x/f0/a1/b7/f0a1b75446e5f6bc22b5a28181ed1e0d.jpg',
      is_available: false,
      free_delivery: false,
    },
    {
      name: 'Mobin Weldings',
      description: "G-Shock Digital Black Dial Unisex's Watch-DW-5610SU-...",
      price: 7995,
      category: 'gates',
      imageurl:
        'https://mulhollandbrand.com/wp-content/uploads/2021/05/2a-4.jpg',
      is_available: true,
      free_delivery: true,
    },
    {
      name: 'Shaun Grill Works',
      description:
        "G-Shock Digital Gold Dial Men's Watch - GD-100GB-1DR (G340)",
      price: 6595,
      category: 'grill',
      imageurl:
        'https://i.pinimg.com/736x/f0/a1/b7/f0a1b75446e5f6bc22b5a28181ed1e0d.jpg',
      is_available: false,
      free_delivery: false,
    },
    {
      name: 'Mobin Weldings',
      description: "G-Shock Digital Black Dial Unisex's Watch-DW-5610SU-...",
      price: 7995,
      category: 'gates',
      imageurl:
        'https://mulhollandbrand.com/wp-content/uploads/2021/05/2a-4.jpg',
      is_available: true,
      free_delivery: true,
    },
    {
      name: 'Shaun Grill Works',
      description:
        "G-Shock Digital Gold Dial Men's Watch - GD-100GB-1DR (G340)",
      price: 6595,
      category: 'grill',
      imageurl:
        'https://i.pinimg.com/736x/f0/a1/b7/f0a1b75446e5f6bc22b5a28181ed1e0d.jpg',
      is_available: false,
      free_delivery: false,
    },
    // Add more products here
  ];

  constructor(
    private userCredentialsService: UserCredentialsService,
    private productService: ProductService,
    private router: Router
  ) {}

  ngOnInit() {
    this.filteredOptions = [];
    this.fetchCategoryData();
  }

  onInput(event: Event) {
    const input = (event.target as HTMLInputElement).value.toLowerCase();
    if (input) {
      this.filteredOptions = this.categoryData
        .filter(
          (item) =>
            item.category.toLowerCase().includes(input) ||
            item.subCategory.toLowerCase().includes(input)
        )
        .map((item) => `${item.category} - ${item.subCategory}`);
    } else {
      this.filteredOptions = [];
    }
  }

  selectOption(option: string) {
    this.myControl.setValue(option);
    this.filteredOptions = [];
  }

  fetchCategoryData(): void {
    this.productService.getAllCategoryData().subscribe(
      (response) => {
        this.categoryData = response.Data;
        console.log(this.categoryData);
      },
      (error) => {
        // this.errorMessage = error.message; // Update to access the message
        console.error('Error fetching data:', error.message);
      }
    );
  }

  searchProducts() {
    const searchTerm = this.myControl.value;
    console.log('Search Term:', searchTerm);
    console.log(this.filteredOptions);

    const parts = searchTerm.split('-').map((part) => part.trim());

    console.log('First Part:', parts[0]);
    console.log('Second Part:', parts[1]);

    this.router.navigate([
      '/products/categorizedproducts/' + parts[0] + '/' + parts[1],
    ]);

    
  }
}
