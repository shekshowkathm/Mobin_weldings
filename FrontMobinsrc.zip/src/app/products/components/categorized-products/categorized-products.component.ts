import { Component } from '@angular/core';
import { TopHeaderComponent } from '../../../home/components/top-header/top-header.component';
import { MainHeaderComponent } from '../../../home/components/main-header/main-header.component';
import { FooterComponent } from '../../../home/components/footer/footer.component';
import { ProductService } from '../../service/product.service';
import { ActivatedRoute } from '@angular/router';
import { MatIconModule } from '@angular/material/icon';
import { NgFor, NgIf, NgStyle } from '@angular/common';

@Component({
  selector: 'app-categorized-products',
  standalone: true,
  imports: [TopHeaderComponent, MainHeaderComponent, FooterComponent,MatIconModule,NgIf,NgFor,NgStyle],
  templateUrl: './categorized-products.component.html',
  styleUrl: './categorized-products.component.scss',
})
export class CategorizedProductsComponent {
  receivedProductsData: any[] = [];

  category: string;
  subCategory: string;

  constructor(
    private productsService: ProductService,
    private route: ActivatedRoute
  ) {
    this.route.paramMap.subscribe((params) => {
      this.category = params.get('category')!;
      this.subCategory = params.get('subCategory')!;

      console.log('First Part:', this.category);
      console.log('Second Part:', this.subCategory);
    });
  }

  ngOnInit() {
    this.getCategorizedProductsData();
  }


  getTruncatedText(text: string): string {
    return text.slice(0, 35);
  }

  getCategorizedProductsData() {
    const queryInfo = {
      category: this.category,
      subCategory: this.subCategory,
    };
    this.productsService.categoryAndSubcategorySearch(queryInfo).subscribe({
      next: (response) => {
        this.receivedProductsData = response.Data;
        console.log(this.receivedProductsData);
      },
      error: (error) => {
        console.log(error);
      },
      complete: () => {
        console.log('Request completed');
      },
    });
  }
}
