export const environment = {
  production: true,
  //   localdomain: 'https://admin.cultureseekerz.com',
  // localdomain: 'http://localhost:8000/',
  localdomain: 'https://mobinweldingbackend-production.up.railway.app/',
  adminToken:
    'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjozLCJyb2xlIjoiQWRtaW4iLCJleHAiOjE3MjA1ODg5NTQsImlhdCI6MTcxOTk4NDE1NH0.SprImcBZ7c3JAgKTVGflGQNp7CnQnIMFxjNJ_gtOr3Q',
  vendorToken:
    'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjo0LCJyb2xlIjoiVmVuZG9yIiwiZXhwIjoxNzIwNTg5MDQwLCJpYXQiOjE3MTk5ODQyNDB9.v2OiskPlDyzJ86WHSZZuCPGcMOLWcly7n_r7kkX2QNI',
  userToken:
    'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjo3LCJyb2xlIjoiVXNlciIsImV4cCI6MTcyMDU4OTA3MSwiaWF0IjoxNzE5OTg0MjcxfQ.lQ8o8qr3mDScR3Ss2cl9j-S3YgbiXW5FGBl91tHG9no',

  encryptionKey: 'a7b8c9d10e11f12g13h14i15j16k17l18m19n20o21p22q23r24s25t26',

  firebaseConfig: {
    apiKey: 'AIzaSyCj5bMIWmtvu06IPe5KICaHxFIYJJzTPh4',
    authDomain: 'mobin-weldings.firebaseapp.com',
    projectId: 'mobin-weldings',
    storageBucket: 'mobin-weldings.appspot.com',
    messagingSenderId: '909951662171',
    appId: '1:909951662171:web:e75b7008924938122f677e',
  },
};
